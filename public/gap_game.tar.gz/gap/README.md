splash screen
background for poll used on each page of it(gathering information about user will be called poll)
poll field styling
poll step tracker list( Like passport or list of things with checkboxes or other thing to show that field is filled or not, on top of background )


human (female,male) x 4 Age groups (19-29,30-39,40-49,50-[60|65]), x15 category for human - clothes
category icon x15
6 interest icons 
category stage x15(split to layers, each neighbor layer will be sequel of previous no cutting)
interest stage x6 multiply to layer_per_interest(5) (each neighbor layer will be sequel of previous no cutting, plus 5 for each interest like middle stage between category and interest)
timeline styling
total box styling
path for human movements(svg path just a line according to background)
loading progess image
end game page design with summary