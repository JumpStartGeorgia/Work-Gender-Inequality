var category = 
[
        { "name": "Agriculture, hunting and forestry" },
        { "name": "Fishing" },
        { "name": "Mining and quarrying" },
        { "name": "Manufacturing" },
        { "name": "Production and distribution of electricity, gas and water" },
        { "name": "Construction" },
        { "name": "Wholesale and retail trade; repair of motor vehicles and personal and household goods" },
        { "name": "Hotels and restaurants" },
        { "name": "Transport and communication" },
        { "name": "Financial intermediation" },
        { "name": "Real estate, renting and business activities" },
        { "name": "Public administration" },
        { "name": "Education" },
        { "name": "Health and social work" },
        { "name": "Other community, social and personal service activities" }
];

var sintro = { "class":"intro", "title":"Gap Game (Just scroll)"};
var poll = {
        gender:{},
        age:{},
        category:{},
        interest:{}
};
var sframe = 
[
        {}
];
var sepilogue = { "class":"epilogue", "title":"Game Over"};
var age_groups = 
[
        { "name":"adolescence", "min":18, "max":29},
        { "name":"young_adulthood", "min":30, "max":39},
        { "name":"middle_adulthood", "min":40, "max":49},
        { "name":"advanced_adulthood", "min":50, "max":65}      
]; 